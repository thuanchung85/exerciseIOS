//
//  ViewController.swift
//  DigitalClock
//
//  Created by test on 4/5/19.
//  Copyright © 2019 test. All rights reserved.
//

import UIKit
import SnapKit

class HomeViewController: UIViewController {
    
    var myTimeLabel:UILabel = {
        let lb = UILabel()
        lb.text = "Time Here"
        lb.textColor = .green
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.textAlignment = .center
        lb.contentMode = .scaleToFill
        lb.numberOfLines = 1
        lb.adjustsFontSizeToFitWidth = true
        lb.minimumScaleFactor = 0.2
        return lb
    }()
    
    var myDateLabel:UILabel = {
        let lb = UILabel()
        lb.font = UIFont(name:"digital-7 Mono", size: 30)
        lb.text = "Date here"
        lb.textColor = .green
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    
    var myDaylabel:UILabel = {
        let lb = UILabel()
        lb.font = UIFont(name:"digital-7 Mono", size: 30)
        lb.text = "Day here"
        lb.textColor = .green
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    
    var myIc_timerButton:UIButton = {
        let bt = UIButton()
         bt.setImage(UIImage.init(named: "ic_timer"), for: .normal)
        return bt
    }()
    
    var myIc_themesButton:UIButton = {
        let bt = UIButton()
        bt.setImage(UIImage.init(named: "ic_themes"), for: .normal)
        return bt
    }()
    
    var myIc_settingsButton:UIButton = {
        let bt = UIButton()
         bt.setImage(UIImage.init(named: "ic_settings"), for: .normal)
        return bt
    }()
    
    var myIc_notificationButton:UIButton = {
        let bt = UIButton()
        bt.setImage(UIImage.init(named: "ic_notification"), for: .normal)
        return bt
    }()
    
    var myOnOffLabel:UILabel = {
        let lb = UILabel()
        lb.text = "OFF"
        lb.textColor = .green
        return lb
    }()
    
     var myTimer:Timer?
    
    //FUNC SETUP myTimer
    func Setup_myTimer()
    {
       
        myTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(Tick_myTimer), userInfo: nil, repeats: true)
    }
    ///FUNC Tick_myTimer
    @objc func Tick_myTimer()
    {
        
        GetCurrentDate(DateStyle: "MMM dd,yyyy") { (Date,DateFormatter) in
            myDateLabel.text = DateFormatter.string(from: Date as Date)
        }
        GetCurrentDate(DateStyle: "EEEE") { (Date,DateFormatter) in
            myDaylabel.text = DateFormatter.string(from: Date as Date)
        }
        GetCurrentTime()
    }
    
    
    //FUNC SETUP myTimeLabel
    func Setup_myTimeLabel()
    {
        self.view.addSubview(myTimeLabel)
        myTimeLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.view.snp.centerX)
            make.centerY.equalTo(self.view.snp.centerY)
        }
    }
    
    //FUNC SETUP myDateLabel
    func Setup_myDateLabel()
    {
        self.view.addSubview(myDateLabel)
        myDateLabel.snp.makeConstraints { (make) in
            make.bottom.equalTo(myTimeLabel.snp.top).offset(5)
            make.trailing.equalTo(myTimeLabel.snp.trailing).offset(0)
        }
    }
    
    //FUNC SETUP myDateLabel
    func Setup_myDayLabel()
    {
        self.view.addSubview(myDaylabel)
        myDaylabel.snp.makeConstraints { (make) in
            make.bottom.equalTo(myTimeLabel.snp.top).offset(5)
            make.leading.equalTo(myTimeLabel.snp.leading).offset(50)
        }
    }
    
   //FUNC SETUP ic_timer Button
    func SetupIc_timerButton()
    {
        self.view.addSubview(myIc_timerButton)
       
        myIc_timerButton.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10)
            make.leading.equalToSuperview().offset(10)
        }
    }
    //FUNC SETUP ic_themes Button
    func SetupIc_themesButton()
    {
        self.view.addSubview(myIc_themesButton)
        
        myIc_themesButton.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().offset(-10)
            make.trailing.equalToSuperview().offset(-10)
        }
    }
    //FUNC SETUP ic_settings Button
    func SetupIc_settingsButton()
    {
        self.view.addSubview(myIc_settingsButton)
       
        myIc_settingsButton.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10)
            make.trailing.equalToSuperview().offset(-10)
        }
    }
    //FUNC SETUP ic_notification Button
    func SetupIc_notificationButton()
    {
        self.view.addSubview(myIc_notificationButton)
        
        myIc_notificationButton.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().offset(-10)
            make.leading.equalToSuperview().offset(10)
        }
    }
    //FUNC SETUP ic_notification Button
    func SetupMyOnOffLable()
    {
        self.view.addSubview(myOnOffLabel)
        
        myOnOffLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(myIc_notificationButton)
            make.leading.equalTo(myIc_notificationButton.snp.trailing).offset(10)
        }
    }
    
    //////VIEW DID LOAD///////
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.view.backgroundColor = .black
        Setup_myTimeLabel()
        Setup_myDateLabel()
        Setup_myDayLabel()
        Setup_myTimer()
        SetupIc_timerButton()
        SetupIc_themesButton()
        SetupIc_settingsButton()
        SetupIc_notificationButton()
        SetupMyOnOffLable()
    }
    
    //////VIEW update Constraints///////
    override func updateViewConstraints() {
        super.updateViewConstraints()
        
    }
        
    
    /////FUNC get curretn DATE/////
    func GetCurrentDate(DateStyle:String, closure: (NSDate,DateFormatter)->()) -> Void {
        let Date:NSDate = NSDate()
        let dateFormat:DateFormatter = DateFormatter()
        dateFormat.dateFormat = DateStyle
        closure(Date,dateFormat)
        
    }
    
    /////FUNC get curretn TIME/////
    func GetCurrentTime() -> Void {
        
        let date = Date()
        let calendar = NSCalendar.current
        let second = calendar.component(.second, from: date)
        
        let formatter = DateFormatter()
        formatter.dateFormat = "hh"
        let hourString = formatter.string(from: Date())
       
        formatter.dateFormat = "a"
        let amOrPM = formatter.string(from: Date())
        
        formatter.dateFormat = "mm"
        let minuterString = formatter.string(from: Date())
        
        let attributedText = NSMutableAttributedString(string: hourString + ":" + minuterString , attributes: [NSAttributedString.Key.font: UIFont(name:"digital-7 Mono", size: 180)!])
        
        attributedText.append(NSAttributedString(string: ":" + String(second) + " " + amOrPM, attributes: [NSAttributedString.Key.font: UIFont(name:"digital-7 Mono", size: 50)!, NSAttributedString.Key.foregroundColor: UIColor.green]))
        myTimeLabel.attributedText = attributedText
       
    }
    
    
    
    
    
}//end class

