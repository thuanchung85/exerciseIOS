//
//  ViewController.swift
//  SalaryCalcualtor
//
//  Created by SWEET HOME (^0^)!!! on 5/13/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import UIKit
import SnapKit

class ViewController: UIViewController {

    
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    func createObserver()
    {
        NotificationCenter.default.addObserver(self, selector: #selector(setupUIforOffice), name: NSNotification.Name.init("Office"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(setupUIforSaleperson), name: NSNotification.Name.init("Saleperson"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(setupUIforWorker), name: NSNotification.Name.init("Worker"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(setupUIforArt), name: NSNotification.Name.init("Art"), object: nil)
    }
    
    @objc func setupUIforOffice()
    {
        print("setupUIforOffice")
        intfCommission.isHidden = true
        intfMultiply.isHidden = false
        intfBaseSalary.isHidden = false
        intfYearsInWork.isHidden = false
        resetInputTextField()
    }
    @objc func setupUIforSaleperson()
    {
        print("setupUIforSaleperson")
        intfCommission.isHidden = false
        intfMultiply.isHidden = true
        intfBaseSalary.isHidden = false
        intfYearsInWork.isHidden = true
        resetInputTextField()
    }
    @objc func setupUIforWorker()
    {
       
        print("setupUIforWorker")
        intfCommission.isHidden = true
        intfMultiply.isHidden = false
        intfBaseSalary.isHidden = false
        intfYearsInWork.isHidden = true
        resetInputTextField()
        
    }
    @objc func setupUIforArt()
    {
        
        print("setupUIforArt")
        intfCommission.isHidden = true
        intfMultiply.isHidden = true
        intfBaseSalary.isHidden = true
        intfYearsInWork.isHidden = true
        resetInputTextField()
        
    }
    
    func resetInputTextField()
    {
        intfCommission.text = ""
        intfCommission.placeholder = "Commission"
        intfMultiply.text = ""
        intfMultiply.placeholder = "Multiply"
        
        intfBaseSalary.text = ""
        intfBaseSalary.placeholder = "Base Salary"
        intfYearsInWork.text = ""
        intfYearsInWork.placeholder = "Years Work"
        
    }
    
    
    var intfCompanyRevenue:UITextField = {
        let tf = UITextField()
        tf.backgroundColor = .white
        tf.translatesAutoresizingMaskIntoConstraints = false
        return tf
    }()
    
    var intfCompanyProducts:UITextField = {
        let tf = UITextField()
        tf.backgroundColor = .white
        tf.translatesAutoresizingMaskIntoConstraints = false
        return tf
    }()
    
    var lbCompanyRevenue:UILabel = {
        let lb = UILabel()
        lb.text = "Company Revenue"
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    
    var lbCompanyProducts:UILabel = {
        let lb = UILabel()
        lb.text = "Company Products"
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    
    var ddbKindsEmployees: DropDownButton = {
        let ddb :DropDownButton = DropDownButton.init(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
        ddb.translatesAutoresizingMaskIntoConstraints = false
        ddb.setTitle("Kinds of Employees", for: .normal)
        let arrKindsOfEmployee = ["Office","Saleperson","Worker","Art","Accounter"]
        ddb.dropDownView.setupMenu(array: arrKindsOfEmployee)
        
        return ddb
    }()
    
    var btSalaryCalculate: UIButton = {
        let bt  = UIButton()
        bt.backgroundColor = .green
        bt.translatesAutoresizingMaskIntoConstraints = false
        bt.setTitle("Salary Calculate", for: .normal)
        bt.addTarget(self, action: #selector(getSalaryInfo), for: .touchUpInside)
        return bt
    }()
    
    var lbSalaryInformation: UILabel = {
        let lb  = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.text = "Salary Informations: "
        return lb
    }()
    var tvSalaryDetail: UITextView = {
        let tv  = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.backgroundColor = .white
        return tv
    }()
    
    var intfYearsInWork: UITextField = {
        let itf  = UITextField()
        itf.translatesAutoresizingMaskIntoConstraints = false
        itf.placeholder = "Years work"
        itf.backgroundColor = .white
        return itf
    }()
    var intfBaseSalary: UITextField = {
        let itf  = UITextField()
        itf.translatesAutoresizingMaskIntoConstraints = false
        itf.placeholder = "Base Salary"
        itf.backgroundColor = .white
        return itf
    }()
    var intfMultiply: UITextField = {
        let itf  = UITextField()
        itf.translatesAutoresizingMaskIntoConstraints = false
        itf.placeholder = "Multiply"
        itf.backgroundColor = .white
        return itf
    }()
    var intfCommission: UITextField = {
        let itf  = UITextField()
        itf.translatesAutoresizingMaskIntoConstraints = false
        itf.placeholder = "Commission"
        itf.backgroundColor = .white
        return itf
    }()
    
    ////VIEW DID LOAD
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        view.backgroundColor = .gray
        setupUI()
        createObserver()
    }
    
    //setupUI
    func setupUI()
    {
        
        self.view.addSubview(intfCompanyProducts)
        intfCompanyProducts.snp.makeConstraints { (make) in
            make.top.equalTo(self.view.safeAreaLayoutGuide.snp.top).inset(10)
            make.centerX.equalTo(self.view.snp.centerX).offset(75)
            make.width.equalTo(200)
            make.height.equalTo(30)
        }
        self.view.addSubview(lbCompanyProducts)
        lbCompanyProducts.snp.makeConstraints { (make) in
            make.trailing.equalTo(intfCompanyProducts.snp.leading).offset(-10)
            make.centerY.equalTo(intfCompanyProducts.snp.centerY)
            
        }
        
        self.view.addSubview(intfCompanyRevenue)
        intfCompanyRevenue.snp.makeConstraints { (make) in
            make.top.equalTo(intfCompanyProducts.snp.bottom).offset(10)
             make.centerX.equalTo(intfCompanyProducts.snp.centerX)
            make.width.equalTo(200)
             make.height.equalTo(30)
        }
        self.view.addSubview(lbCompanyRevenue)
        lbCompanyRevenue.snp.makeConstraints { (make) in
            make.trailing.equalTo(intfCompanyRevenue.snp.leading).offset(-10)
            make.centerY.equalTo(intfCompanyRevenue.snp.centerY)
           
        }
        
        self.view.addSubview(ddbKindsEmployees)
        ddbKindsEmployees.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.view.snp.centerX)
            make.centerY.equalTo(intfCompanyRevenue.snp.centerY).offset(50)
            make.width.equalTo(200)
            make.height.equalTo(40)
        }
        
        self.view.addSubview(btSalaryCalculate)
        btSalaryCalculate.snp.makeConstraints { (make) in
            make.centerX.equalTo(ddbKindsEmployees)
            make.bottom.equalTo(self.view.snp.bottom).inset(20)
            make.width.equalTo(200)
            make.height.equalTo(40)
        }
        
        self.view.addSubview(lbSalaryInformation)
        lbSalaryInformation.snp.makeConstraints { (make) in
            make.leading.equalTo(self.view.snp.leading).inset(20)
            make.top.equalTo(ddbKindsEmployees.snp.bottom).offset(200)
        }
        
        self.view.addSubview(tvSalaryDetail)
        tvSalaryDetail.snp.makeConstraints { (make) in
            make.leading.equalTo(lbSalaryInformation.snp.leading)
            make.top.equalTo(lbSalaryInformation.snp.bottom).offset(10)
            make.trailing.equalTo(self.view.snp.trailing).inset(20)
            make.height.equalTo(200)
        }
        ///OFFICE field
        self.view.addSubview(intfYearsInWork)
        intfYearsInWork.snp.makeConstraints { (make) in
            make.bottom.equalTo(lbSalaryInformation.snp.top).offset(-10)
            make.leading.equalTo(self.view.snp.leading).inset(20)
            make.width.equalTo(100)
            make.height.equalTo(30)
        }
        self.view.addSubview(intfBaseSalary)
        intfBaseSalary.snp.makeConstraints { (make) in
            make.bottom.equalTo(lbSalaryInformation.snp.top).offset(-10)
            make.leading.equalTo(intfYearsInWork.snp.trailing).offset(10)
            make.width.equalTo(100)
            make.height.equalTo(30)
        }
        self.view.addSubview(intfMultiply)
        intfMultiply.snp.makeConstraints { (make) in
            make.bottom.equalTo(lbSalaryInformation.snp.top).offset(-10)
            make.leading.equalTo(intfBaseSalary.snp.trailing).offset(10)
            make.width.equalTo(50)
            make.height.equalTo(30)
        }
        self.view.addSubview(intfCommission)
        intfCommission.snp.makeConstraints { (make) in
            make.bottom.equalTo(lbSalaryInformation.snp.top).offset(-10)
            make.leading.equalTo(intfMultiply.snp.trailing).offset(10)
            make.width.equalTo(50)
            make.height.equalTo(30)
        }
    }

    //
    @objc func getSalaryInfo ()
    {
        if let x:Int = Int(intfCompanyProducts.text!)
        {
            Company.products = abs(Int64(x))
        }
        else
        {
             tvSalaryDetail.text = "Please input Products!"
            return
        }
        
        if let x = Double(intfCompanyRevenue.text!)
        {
            Company.revenue = abs(Double(x))
        }
        else
        {
            tvSalaryDetail.text = "Please input Revenue!"
            return
        }
        
        switch ddbKindsEmployees.titleLabel?.text {
        case "Office":
            guard let guardedBaseSalary = Double(intfBaseSalary.text!) else{ return}
            guard let guardedMultiply = Double(intfMultiply.text!) else {return}
            guard let guardedYearsInWork = Int(intfYearsInWork.text!) else {return}
            
            let office:Office = Office(baseSalary: guardedBaseSalary, multiply: guardedMultiply, yearsInWork: guardedYearsInWork)
             tvSalaryDetail.text = "Salary of Office"
            tvSalaryDetail.text = tvSalaryDetail.text + "\n" + office.getIncome() + "$"
            
        case "Saleperson":
            guard let guardedBaseSalary = Double(intfBaseSalary.text!) else{ return}
            guard let guardedPercentCommission = Double(intfCommission.text!) else {return}
            
            let saleperson:Saleperson = Saleperson(baseSalary: guardedBaseSalary, percentCommission: guardedPercentCommission)
             tvSalaryDetail.text = "Salary of Saleperson"
             tvSalaryDetail.text = tvSalaryDetail.text + "\n" + saleperson.getIncome() + "$"
            
        case "Worker":
            guard let guardedBaseSalary = Double(intfBaseSalary.text!) else{ return}
              guard let guardedMultiply = Double(intfMultiply.text!) else {return}
            
            let worker:Worker = Worker(baseSalary: guardedBaseSalary, multiply: guardedMultiply)
             tvSalaryDetail.text = "Salary of Worker"
            tvSalaryDetail.text = tvSalaryDetail.text + "\n" + worker.getIncome() + "$"
            
        default:
             tvSalaryDetail.text = "please choose kinds of employee"
        }
       
    }
    
    
}//end class

