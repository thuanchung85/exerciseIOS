//
//  SalaryCalculateFunctions.swift
//  SalaryCalculator
//
//  Created by test on 5/15/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import Foundation

class SalaryCalculateFunctions {
    
   static func setOfficeSalary(baseSalary: Double, multiply:Double, yearsInWork:Int)->Double
    {
        let baseSalary = abs(baseSalary)
        let multiply = abs(multiply)
        let yearsInWork = abs(yearsInWork)
        let allowance:Double
        if(yearsInWork < 10){
            allowance = baseSalary
        }
        else{
            allowance = baseSalary * 1.2
        }
        return  multiply * baseSalary + allowance
    }
    
   static func setSalepersonSalary(companyRevenue:Double ,baseSalary: Double, percentCommission:Double)->Double
    {
        let baseSalary = abs(baseSalary)
        let percentCommission = abs(percentCommission)
        let reward = (abs(companyRevenue) * percentCommission)/100
        return baseSalary + reward
    }
    
   static func setWorkerSalary(companyProduct:Int64 ,baseSalary: Double, multiply:Double)->Double
    {
        let baseSalary = abs(baseSalary)
        let multiply = abs(multiply)
        let reward:Double
        if (companyProduct < 1000){
            reward = baseSalary
        }
        else{
            reward = baseSalary * 1.5
        }
        
        return multiply * baseSalary + reward
    }
}//end class
