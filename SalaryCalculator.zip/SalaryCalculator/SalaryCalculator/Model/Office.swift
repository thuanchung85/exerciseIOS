//
//  Office.swift
//  SalaryCalcualtor
//
//  Created by SWEET HOME (^0^)!!! on 5/13/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import Foundation
class Office: Employees
{
   
    private var baseSalary: Double?
    private var multiply: Double?
    private var allowance: Double?
    private var yearsInWork: Int?
    
  
    
    //Func INIT
    init(baseSalary:Double, multiply:Double, yearsInWork:Int) {
        super.init(kinds: .office)
       
        self.baseSalary = abs(baseSalary)
        self.multiply = abs(multiply)
        self.yearsInWork = abs(yearsInWork)
        if(self.yearsInWork! < 10){
            allowance = self.baseSalary!
        }
        else{
            allowance = self.baseSalary! * 1.2
        }
        
        self.setIncome(income: self.multiply! * self.baseSalary! + self.allowance! )
       
    }
    
   
   
   
}
