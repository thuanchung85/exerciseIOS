//
//  Company.swift
//  SalaryCalcualtor
//
//  Created by SWEET HOME (^0^)!!! on 5/13/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import Foundation

class Company {
    static var revenue: Double = 1
    static var products: Int64 = 1
}
