//
//  Emplyee.swift
//  SalaryCalcualtor
//
//  Created by SWEET HOME (^0^)!!! on 5/13/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import Foundation

enum KindsOfEmployee
{
    case office
    case worker
    case saleperson
}

class Employees
{
    private var kinds:KindsOfEmployee?
    private var totalIncome: Double?
    
    //Func INIT
    init(kinds:KindsOfEmployee) {
      
       self.kinds = kinds
        
    }
    
    
    //func Set Income
     func setIncome(income:Double)
    {
        totalIncome = income
        
    }
    //func Get Income
    public func getIncome()->Double
    {
        guard let income = totalIncome else {return 0}
        return income
    }
    
}//end class
