//
//  Saleperson.swift
//  SalaryCalcualtor
//
//  Created by SWEET HOME (^0^)!!! on 5/13/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import Foundation
class Saleperson: Employees
{
  
    private var baseSalary: Double?
    private var reward: Double?
    private var percentCommission: Double?
    
    //Func INIT
    init(baseSalary:Double, percentCommission:Double) {
        super.init(kinds: .saleperson)
        
        self.baseSalary = abs(baseSalary)
        self.percentCommission = abs(percentCommission)
        self.reward = (Company.revenue * self.percentCommission!)/100
        self.setIncome(income: self.baseSalary! + self.reward! )
        
    }

}
