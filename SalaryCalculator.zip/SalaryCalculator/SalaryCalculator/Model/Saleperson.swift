//
//  Saleperson.swift
//  SalaryCalcualtor
//
//  Created by SWEET HOME (^0^)!!! on 5/13/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import Foundation
class Saleperson: Employees
{
  
    private var baseSalary: Double?
    private var reward: Double?
    private var percentCommission: Double?
    
    //Func INIT
    init(baseSalary:Double, percentCommission:Double) {
        super.init(kinds: .saleperson)
        
        self.baseSalary = abs(baseSalary)
        self.percentCommission = abs(percentCommission)
        
    }
    //func Get baseSalary
    public func getBaseSalary()->Double
    {
        guard let x = baseSalary else {return 0}
        return x
    }
    //func Get percentCommission
    public func getPercentCommission()->Double
    {
        guard let x = percentCommission else {return 0}
        return x
    }
    

}
