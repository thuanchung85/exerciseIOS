//
//  Worker.swift
//  SalaryCalcualtor
//
//  Created by SWEET HOME (^0^)!!! on 5/13/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import Foundation
class Worker: Employees
{
    
    private var baseSalary: Double?
    private var multiply: Double?
    private var reward: Double?
    
    //Func INIT
    init(baseSalary:Double, multiply:Double) {
        super.init(kinds: .worker)
        
        self.baseSalary = abs(baseSalary)
        self.multiply = abs(multiply)
        if (Company.products < 1000){
            self.reward = self.baseSalary!
        }
        else{
            self.reward = self.baseSalary! * 1.5
        }
        
        self.setIncome(income: self.multiply! * self.baseSalary! + self.reward! )
        
    }
  
 
}
