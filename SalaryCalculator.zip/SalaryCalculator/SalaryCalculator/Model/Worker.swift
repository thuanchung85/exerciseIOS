//
//  Worker.swift
//  SalaryCalcualtor
//
//  Created by SWEET HOME (^0^)!!! on 5/13/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import Foundation
class Worker: Employees
{
    
    private var baseSalary: Double?
    private var multiply: Double?
    private var reward: Double?
    
    //Func INIT
    init(baseSalary:Double, multiply:Double) {
        super.init(kinds: .worker)
        
        self.baseSalary = abs(baseSalary)
        self.multiply = abs(multiply)
        
    }
    //func Get baseSalary
    public func getBaseSalary()->Double
    {
        guard let x = baseSalary else {return 0}
        return x
    }
    //func Get multiply
    public func getMultiply()->Double
    {
        guard let x = multiply else {return 0}
        return x
    }
   
 
}
