//
//  Theme.swift
//  SalaryCalculator
//
//  Created by SWEET HOME (^0^)!!! on 5/15/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import UIKit
class Theme {
    static let backgroundColor = UIColor.init(named: "backgroundColor")
    static let tintColor = UIColor.init(named: "tintColor")
    static let textColor = UIColor.init(named: "textColor")
    static let accentColor = UIColor.init(named: "accentColor")
}
