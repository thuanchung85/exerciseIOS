//
//  ProtocolOfDropDownButton.swift
//  SalaryCalcualtor
//
//  Created by SWEET HOME (^0^)!!! on 5/13/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import Foundation
protocol ProtocolOfDropDownButton {
    func DelegateYouMustDoSomeThing(string:String)
}
