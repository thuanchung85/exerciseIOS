//
//  EmployeesInformationView.swift
//  SalaryCalculator
//
//  Created by test on 5/15/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import UIKit
import SnapKit

class EmployeesInformationScreenUIView: UIView {

    var lbTitle:UILabel = {
        let lb:UILabel = UILabel()
        lb.text = "EMPLOYEE INFORMATIONS"
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    
    var lbName:UILabel = {
        let lb:UILabel = UILabel()
        lb.text = "Name: "
         lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    var intfName:UITextField = {
        let intf:UITextField = UITextField()
        intf.placeholder = "name of employee"
        intf.translatesAutoresizingMaskIntoConstraints = false
        intf.backgroundColor = .white
        return intf
    }()
    
    var lbHomeTown:UILabel = {
        let lb:UILabel = UILabel()
        lb.text = "Hometown: "
         lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    var intfHomeTown:UITextField = {
        let intf:UITextField = UITextField()
        intf.placeholder = "hometown of employee"
        intf.translatesAutoresizingMaskIntoConstraints = false
         intf.backgroundColor = .white
        return intf
    }()
    
    var lbBirthYear:UILabel = {
        let lb:UILabel = UILabel()
        lb.text = "Year of birth: "
         lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    var intfBirthYear:UITextField = {
        let intf:UITextField = UITextField()
        intf.placeholder = "employee's birth year"
        intf.translatesAutoresizingMaskIntoConstraints = false
         intf.backgroundColor = .white
        return intf
    }()
    
    var lbEnrollYear:UILabel = {
        let lb:UILabel = UILabel()
        lb.text = "Year to enroll: "
         lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    var intfEnroll:UITextField = {
        let intf:UITextField = UITextField()
        intf.placeholder = "year to enroll"
        intf.translatesAutoresizingMaskIntoConstraints = false
         intf.backgroundColor = .white
        return intf
    }()
    
    var btNext: UIButton = {
        let bt  = UIButton()
        bt.backgroundColor = Theme.accentColor
        bt.setTitleColor(Theme.textColor, for: .normal)
        bt.layer.cornerRadius = 10
        bt.translatesAutoresizingMaskIntoConstraints = false
        bt.setTitle("Next to Salary Calculate", for: .normal)
        return bt
    }()
    
    //func setupUI
    func setupUI()
    {
        self.addSubview(lbTitle)
        lbTitle.snp.makeConstraints { (make) in
            make.top.equalTo(self.safeAreaLayoutGuide.snp.top).inset(5)
            make.centerX.equalTo(self.snp.centerX)
        }
        
         self.addSubview(lbName)
        lbName.snp.makeConstraints { (make) in
            make.top.equalTo(lbTitle.snp.bottom).offset(10)
            make.leading.equalTo(self.snp.leading).inset(10)
            make.width.equalTo(120)
            
        }
        self.addSubview(intfName)
        intfName.snp.makeConstraints { (make) in
            make.top.equalTo(lbName.snp.top)
            make.leading.equalTo(lbName.snp.trailing).offset(5)
            make.trailing.equalTo(self.snp.trailing).inset(5)
            make.height.equalTo(25)
        }
        
        self.addSubview(lbHomeTown)
        lbHomeTown.snp.makeConstraints { (make) in
            make.top.equalTo(lbName.snp.bottom).offset(10)
            make.leading.equalTo(self.snp.leading).inset(10)
            make.width.equalTo(120)
        }
        self.addSubview(intfHomeTown)
        intfHomeTown.snp.makeConstraints { (make) in
            make.top.equalTo(lbHomeTown.snp.top)
            make.leading.equalTo(lbName.snp.trailing).offset(5)
            make.trailing.equalTo(self.snp.trailing).inset(5)
            make.height.equalTo(25)
        }
        
         self.addSubview(lbBirthYear)
        lbBirthYear.snp.makeConstraints { (make) in
            make.top.equalTo(lbHomeTown.snp.bottom).offset(10)
            make.leading.equalTo(self.snp.leading).inset(10)
            make.width.equalTo(120)
        }
        self.addSubview(intfBirthYear)
        intfBirthYear.snp.makeConstraints { (make) in
            make.top.equalTo(lbBirthYear.snp.top)
            make.leading.equalTo(lbName.snp.trailing).offset(5)
            make.trailing.equalTo(self.snp.trailing).inset(5)
            make.height.equalTo(25)
        }
        
        self.addSubview(lbEnrollYear)
        lbEnrollYear.snp.makeConstraints { (make) in
            make.top.equalTo(lbBirthYear.snp.bottom).offset(10)
            make.leading.equalTo(self.snp.leading).inset(10)
            make.width.equalTo(120)
        }
        self.addSubview(intfEnroll)
        intfEnroll.snp.makeConstraints { (make) in
            make.top.equalTo(lbEnrollYear.snp.top)
            make.leading.equalTo(lbName.snp.trailing).offset(5)
            make.trailing.equalTo(self.snp.trailing).inset(5)
            make.height.equalTo(25)
        }
        self.addSubview(btNext)
        btNext.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.safeAreaLayoutGuide.snp.bottom).inset(5)
            make.centerX.equalTo(self.safeAreaLayoutGuide.snp.centerX)
            make.width.equalTo(220)
            make.height.equalTo(40)
        }
        btNext.addTarget(self, action: #selector(showviewOfViewController), for: .touchUpInside)
    }
    
    ///
    @objc func showviewOfViewController(){
        
    }
    
    //===============================================================
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = Theme.backgroundColor
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
