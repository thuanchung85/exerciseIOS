//
//  ViewController.swift
//  SalaryCalcualtor
//
//  Created by SWEET HOME (^0^)!!! on 5/13/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import UIKit
import SnapKit

class ViewController: UIViewController {

    ///---------SALARY CACULLATOR SCREEN-------------------
    var salaryCalculatorScreen:SalaryCalculatorScreenUIView = {
       let scr = SalaryCalculatorScreenUIView()
        scr.translatesAutoresizingMaskIntoConstraints = false
        return scr
    }()
    
    func setupUISalaryCalculatorScreen()
    {
         self.view.addSubview(salaryCalculatorScreen)
        salaryCalculatorScreen.snp.makeConstraints { (make) in
            make.top.equalTo(self.view.snp.top)
            make.bottom.equalTo(self.view.snp.bottom)
            make.leading.equalTo(self.view.snp.leading)
            make.trailing.equalTo(self.view.snp.trailing)
        }
    }
    
    ///---------EMPLOYEE INFORMATION SCREEN-------------------
    var employeeInformationScreen:EmployeesInformationScreenUIView = {
        let scr = EmployeesInformationScreenUIView()
        scr.translatesAutoresizingMaskIntoConstraints = false
        return scr
    }()
    
    func setupUIEmployeesInformationScreenUIView()
    {
        self.view.addSubview(employeeInformationScreen)
        employeeInformationScreen.snp.makeConstraints { (make) in
            make.top.equalTo(self.view.snp.top)
            make.bottom.equalTo(self.view.snp.bottom)
            make.leading.equalTo(self.view.snp.leading)
            make.trailing.equalTo(self.view.snp.trailing)
        }
    }
//===============================================================
    ////VIEW DID LOAD
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
      
        setupUISalaryCalculatorScreen()
        //setupUIEmployeesInformationScreenUIView()
    }
    
   
    
    
    
    
}//end class

