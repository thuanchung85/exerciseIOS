//
//  DropDownButton.swift
//  SalaryCalcualtor
//
//  Created by SWEET HOME (^0^)!!! on 5/13/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import UIKit



class DropDownButton:UIButton, ProtocolOfDropDownButton {
    
   
    
    var heightOfDropDownView = NSLayoutConstraint()
    
    var dropDownView : DropDownView={
        let ddv = DropDownView.init(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
        ddv.translatesAutoresizingMaskIntoConstraints = false
       
        return ddv
    }()
    
    ////INIT Button
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .red
        
         dropDownView.deletage = self
        
    }
    //Button already exit and constraint to superview
    override func didMoveToSuperview() {
        
        self.superview?.addSubview(dropDownView)
        self.superview?.bringSubviewToFront(dropDownView)
        
        dropDownView.topAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        dropDownView.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        dropDownView.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        heightOfDropDownView = dropDownView.heightAnchor.constraint(equalToConstant: 0)
    }
    ////
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    /////When button touches
    var isOpen = false
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if isOpen == false
        {
            NSLayoutConstraint.deactivate([heightOfDropDownView])
            heightOfDropDownView.constant = self.dropDownView.tableView.contentSize.height
            NSLayoutConstraint.activate([heightOfDropDownView])
            self.superview?.bringSubviewToFront(dropDownView)
            isOpen = true
        }
        else
        {
            NSLayoutConstraint.deactivate([heightOfDropDownView])
            heightOfDropDownView.constant = 0
            NSLayoutConstraint.activate([heightOfDropDownView])
            
            isOpen = false
        }
    }
    
    //implement func DelegateYouMustDoSomeThing for ProtocolOfDropDownButton
    func DelegateYouMustDoSomeThing(string: String) {
        self.setTitle(string, for: .normal)
        NSLayoutConstraint.deactivate([heightOfDropDownView])
        heightOfDropDownView.constant = 0
        NSLayoutConstraint.activate([heightOfDropDownView])
        isOpen = false
        
        //noifify auto generate        
        for index in 0...dropDownView.dropdownOptions.count - 1
        {
            
            if dropDownView.dropdownOptions[index] == string
            {
               NotificationCenter.default.post(name:  dropDownView.ArrNotificationName[index], object: nil)
                return
            }
        }
        
        
    }
    
    
}//end class
