//
//  DropDownView.swift
//  SalaryCalcualtor
//
//  Created by SWEET HOME (^0^)!!! on 5/13/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import UIKit

class DropDownView:UIView, UITableViewDataSource, UITableViewDelegate {
    
    var dropdownOptions = [String]()
    var  ArrNotificationName = [NSNotification.Name]()
    
    //DropDown view need a some one become delegate for it
    var deletage: ProtocolOfDropDownButton?
    
    var tableView:UITableView =  {
        let tbv = UITableView()
        tbv.register(UITableViewCell.self, forCellReuseIdentifier: "cellid")
        tbv.translatesAutoresizingMaskIntoConstraints = false
        return tbv
    }()
    
    ///INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        tableView.delegate = self
        tableView.dataSource = self
        addSubview(tableView)
        tableView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        tableView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        tableView.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        tableView.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
    }
    ///
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    ///
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    ///
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dropdownOptions.count
    }
    ///
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellid", for: indexPath)
        cell.textLabel?.text = dropdownOptions[indexPath.row]
        return cell
    }
    
    ///when table selected a row
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       //deletage must do some thing
        deletage?.DelegateYouMustDoSomeThing(string: dropdownOptions[indexPath.row])
       
    }
    
    //setup Array ArrNotificationName
    func setupMenu(array: [String])
    {
        dropdownOptions = array
        for index in 0...dropdownOptions.count - 1
        {
            ArrNotificationName.append(NSNotification.Name.init(dropdownOptions[index]))
        }
    }
}
