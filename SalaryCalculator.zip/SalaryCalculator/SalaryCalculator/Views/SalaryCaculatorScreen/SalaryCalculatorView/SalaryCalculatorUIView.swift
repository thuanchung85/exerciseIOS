//
//  SalaryCalculatorUIView.swift
//  SalaryCalculator
//
//  Created by SWEET HOME (^0^)!!! on 5/15/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import UIKit

class SalaryCalculatorUIView: UIView {

   
    var lbSalaryInformation: UILabel = {
        let lb  = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.text = "Salary Informations: "
        return lb
    }()
    var tvSalaryDetail: UITextView = {
        let tv  = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.backgroundColor = .white
        return tv
    }()
    var btSalaryCalculate: UIButton = {
        let bt  = UIButton()
        bt.backgroundColor = Theme.accentColor
        bt.setTitleColor(Theme.textColor, for: .normal)
        bt.layer.cornerRadius = 10
        bt.translatesAutoresizingMaskIntoConstraints = false
        bt.setTitle("Salary Calculate", for: .normal)
        return bt
    }()
    
    ////////INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.clear
        
        self.addSubview(lbSalaryInformation)
        lbSalaryInformation.snp.makeConstraints { (make) in
            make.leading.equalTo(self.snp.leading)
            make.top.equalTo(self.snp.top)
        }
        
        self.addSubview(tvSalaryDetail)
        tvSalaryDetail.snp.makeConstraints { (make) in
            make.leading.equalTo(self.snp.leading)
            make.top.equalTo(lbSalaryInformation.snp.bottom).offset(10)
            make.trailing.equalTo(self.snp.trailing)
            make.height.equalTo(200)
        }
        
        self.addSubview(btSalaryCalculate)
        btSalaryCalculate.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.snp.centerX)
            make.top.equalTo(tvSalaryDetail.snp.bottom).offset(20)
            make.width.equalTo(200)
            make.height.equalTo(40)
        }
        self.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.btSalaryCalculate.snp.bottom).offset(10)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
