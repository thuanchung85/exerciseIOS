//
//  CompanyUIView.swift
//  SalaryCalculator
//
//  Created by SWEET HOME (^0^)!!! on 5/15/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import UIKit

class CompanyUIView: UIView {

    
    var lbCompanyProducts:UILabel = {
        let lb = UILabel()
        lb.text = "Company Products"
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    var intfCompanyProducts:UITextField = {
        let tf = UITextField()
        tf.backgroundColor = .white
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: tf.frame.size.height))
        tf.leftViewMode = .always
        return tf
    }()
    
    var lbCompanyRevenue:UILabel = {
        let lb = UILabel()
        lb.text = "Company Revenue"
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    var intfCompanyRevenue:UITextField = {
        let tf = UITextField()
        tf.backgroundColor = .white
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: tf.frame.size.height))
        tf.leftViewMode = .always
        return tf
    }()
    
    ////////INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.clear
        
        self.addSubview(intfCompanyProducts)
        intfCompanyProducts.snp.makeConstraints { (make) in
            make.top.equalTo(self.safeAreaLayoutGuide.snp.top).inset(10)
            make.centerX.equalTo(self.snp.centerX).offset(75)
            make.width.equalTo(200)
            make.height.equalTo(30)
        }
        self.addSubview(lbCompanyProducts)
        lbCompanyProducts.snp.makeConstraints { (make) in
            make.trailing.equalTo(intfCompanyProducts.snp.leading).offset(-10)
            make.centerY.equalTo(intfCompanyProducts.snp.centerY)
            
        }
        
        self.addSubview(intfCompanyRevenue)
        intfCompanyRevenue.snp.makeConstraints { (make) in
            make.top.equalTo(intfCompanyProducts.snp.bottom).offset(10)
            make.centerX.equalTo(intfCompanyProducts.snp.centerX)
            make.width.equalTo(200)
            make.height.equalTo(30)
        }
        self.addSubview(lbCompanyRevenue)
        lbCompanyRevenue.snp.makeConstraints { (make) in
            make.trailing.equalTo(intfCompanyRevenue.snp.leading).offset(-10)
            make.centerY.equalTo(intfCompanyRevenue.snp.centerY)
            
        }
        
        self.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.lbCompanyRevenue.snp.bottom).offset(10)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
