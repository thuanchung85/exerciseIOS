//
//  WorkerUIView.swift
//  SalaryCalculator
//
//  Created by SWEET HOME (^0^)!!! on 5/15/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import UIKit

class WorkerUIView: UIView {

    var intfBaseSalary: UITextField = {
        let itf  = UITextField()
        itf.translatesAutoresizingMaskIntoConstraints = false
        itf.placeholder = "Base Salary"
        itf.backgroundColor = .white
        itf.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: itf.frame.size.height))
        itf.leftViewMode = .always
        return itf
    }()
    var intfMultiply: UITextField = {
        let itf  = UITextField()
        itf.translatesAutoresizingMaskIntoConstraints = false
        itf.placeholder = "Multiply"
        itf.backgroundColor = .white
        itf.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: itf.frame.size.height))
        itf.leftViewMode = .always
        return itf
    }()
    //reset all input textFields
    func resetAllFields()
    {
        intfBaseSalary.text = ""
        intfMultiply.text = ""
        intfBaseSalary.placeholder = "Base Salary"
        intfMultiply.placeholder = "Multiply"
    }
    ////////INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = Theme.tintColor
        
        addSubview(intfBaseSalary)
        intfBaseSalary.snp.makeConstraints { (make) in
            make.top.equalTo(self.snp.top).inset(5)
            make.leading.equalTo(self.snp.leading).inset(5)
            make.trailing.equalTo(self.snp.trailing).inset(5)
            make.height.equalTo(30)
        }
       
        addSubview(intfMultiply)
        intfMultiply.snp.makeConstraints { (make) in
            make.top.equalTo(intfBaseSalary.snp.bottom).offset(10)
            make.leading.equalTo(intfBaseSalary.snp.leading)
            make.trailing.equalTo(intfBaseSalary.snp.trailing)
            make.height.equalTo(30)
        }
        
        self.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.intfMultiply.snp.bottom).offset(5)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
