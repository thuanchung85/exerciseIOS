//
//  SalaryCalculatorScreen.swift
//  SalaryCalculator
//
//  Created by test on 5/15/19.
//  Copyright © 2019 LUONG THUAN CHUNG. All rights reserved.
//

import UIKit
import SnapKit

class SalaryCalculatorScreenUIView: UIView {
    
    //--------------COMPANY INFORMATION AREA----------------
    lazy var companyUIView:CompanyUIView = {
        let cpv = CompanyUIView()
        cpv.translatesAutoresizingMaskIntoConstraints = false
        return cpv
    }()
    
    func layoutCompanyUIView()
    {
        //company informations view
        self.addSubview(companyUIView)
        companyUIView.snp.makeConstraints { (make) in
            make.top.equalTo(self.safeAreaLayoutGuide.snp.top)
            make.leading.equalTo(self.safeAreaLayoutGuide.snp.leading)
            make.trailing.equalTo(self.safeAreaLayoutGuide.snp.trailing)
        }
        
    }
    
    //----------------DROP DOWN BUTTON AREA------------------------------
    var ddbKindsEmployees: DropDownButton = {
        let ddb :DropDownButton = DropDownButton.init(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
        ddb.translatesAutoresizingMaskIntoConstraints = false
        ddb.setTitle("Kinds of Employees", for: .normal)
        ddb.backgroundColor = Theme.accentColor
        ddb.setTitleColor(Theme.textColor, for: .normal)
        ddb.dropDownView.setupMenu(array: ["Office","Saleperson","Worker"])
        return ddb
    }()
    
    func createObserver()
    {
        NotificationCenter.default.addObserver(self, selector: #selector(setupUIforOffice), name: NSNotification.Name.init("Office"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(setupUIforSaleperson), name: NSNotification.Name.init("Saleperson"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(setupUIforWorker), name: NSNotification.Name.init("Worker"), object: nil)
    }
    
    @objc func setupUIforOffice()
    {
        print("setupUIforOffice")
        self.officeUIView.isHidden = false
        self.salepersonUIView.isHidden = true
        self.workerUIView.isHidden = true
        self.officeUIView.resetAllFields()
    }
    @objc func setupUIforSaleperson()
    {
        print("setupUIforSaleperson")
        self.officeUIView.isHidden = true
        self.salepersonUIView.isHidden = false
        self.workerUIView.isHidden = true
        self.salepersonUIView.resetAllFields()
    }
    @objc func setupUIforWorker()
    {
        print("setupUIforWorker")
        self.officeUIView.isHidden = true
        self.salepersonUIView.isHidden = true
        self.workerUIView.isHidden = false
        self.workerUIView.resetAllFields()
    }
    //when remove viewcontroller we deallocation Observers from memory
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    func layoutDDBKindsEmployees()
    {
        //DropDown Button kinds of employees
        self.addSubview(ddbKindsEmployees)
        ddbKindsEmployees.snp.makeConstraints { (make) in
            make.top.equalTo(companyUIView.snp.bottom).offset(10)
            make.leading.equalTo(companyUIView.intfCompanyRevenue.snp.leading)
            make.width.equalTo(200)
            make.height.equalTo(40)
        }
        
    }
    //---------------EMPLOYEES VIEW AREA-------------------------------
    
    lazy var officeUIView:OfficeUIView = {
        let ov = OfficeUIView()
        ov.translatesAutoresizingMaskIntoConstraints = false
        ov.isHidden = true
        return ov
    }()
    lazy var salepersonUIView:SalepersonUIView = {
        let spv = SalepersonUIView()
        spv.isHidden = true
        spv.translatesAutoresizingMaskIntoConstraints = false
        return spv
    }()
    lazy var workerUIView:WorkerUIView = {
        let wkv = WorkerUIView()
        wkv.isHidden = true
        wkv.translatesAutoresizingMaskIntoConstraints = false
        return wkv
    }()
    
    func layoutEmployeesView()
    {
        ///office VIEW
        self.addSubview(officeUIView)
        officeUIView.snp.makeConstraints { (make) in
            make.top.equalTo(ddbKindsEmployees.snp.bottom).offset(20)
            make.leading.equalTo(companyUIView.snp.leading).offset(10)
            make.trailing.equalTo(companyUIView.snp.trailing).offset(-10)
        }
        ///Saleperson VIEW
        self.addSubview(salepersonUIView)
        salepersonUIView.snp.makeConstraints { (make) in
            make.top.equalTo(ddbKindsEmployees.snp.bottom).offset(20)
            make.leading.equalTo(companyUIView.snp.leading).offset(10)
            make.trailing.equalTo(companyUIView.snp.trailing).offset(-10)
        }
        ///Worker VIEW
        self.addSubview(workerUIView)
        workerUIView.snp.makeConstraints { (make) in
            make.top.equalTo(ddbKindsEmployees.snp.bottom).offset(20)
            make.leading.equalTo(companyUIView.snp.leading).offset(10)
            make.trailing.equalTo(companyUIView.snp.trailing).offset(-10)
        }
        
    }
    
    //---------------SALARY CALCULATOR VIEW AREA-------------------------------
    
    lazy var salaryCalculatorView : SalaryCalculatorUIView = {
        let slv = SalaryCalculatorUIView()
        slv.translatesAutoresizingMaskIntoConstraints = false
        return slv
    }()
    
    func layoutSalaryCalculatorView()
    {
        //salary calculator view
        self.addSubview(salaryCalculatorView)
        salaryCalculatorView.snp.makeConstraints { (make) in
            make.top.equalTo(officeUIView.snp.bottom).offset(20)
            make.leading.equalTo(officeUIView.snp.leading)
            make.trailing.equalTo(officeUIView.snp.trailing)
            
        }
        salaryCalculatorView.btSalaryCalculate.addTarget(self, action: #selector(getSalaryInfo), for: .touchUpInside)
    }
    //when btSalaryCalculate tuoch
    @objc func getSalaryInfo ()
    {
        if let x:Int = Int(companyUIView.intfCompanyProducts.text!)
        {
            Company.products = abs(Int64(x))
        }
        else
        {
            salaryCalculatorView.tvSalaryDetail.text = "Please input Products!"
            return
        }
        
        if let x = Double(companyUIView.intfCompanyRevenue.text!)
        {
            Company.revenue = abs(Double(x))
        }
        else
        {
            salaryCalculatorView.tvSalaryDetail.text = "Please input Revenue!"
            return
        }
        
        switch ddbKindsEmployees.titleLabel?.text {
        case "Office":
            guard let guardedBaseSalary = Double(officeUIView.intfBaseSalary.text!) else{ return}
            guard let guardedMultiply = Double(officeUIView.intfMultiply.text!) else {return}
            guard let guardedYearsInWork = Int(officeUIView.intfYearsInWork.text!) else {return}
            
            let office:Office = Office(baseSalary: guardedBaseSalary, multiply: guardedMultiply, yearsInWork: guardedYearsInWork)
            let salary = SalaryCalculateFunctions.setOfficeSalary(baseSalary: office.getBaseSalary(), multiply: office.getMultiply(), yearsInWork: office.getYearsInWork())
            office.setIncome(income: salary)
            
            salaryCalculatorView.tvSalaryDetail.text = "Salary of Office \n \(office.getIncome()) $"
            
        case "Saleperson":
            guard let guardedBaseSalary = Double(salepersonUIView.intfBaseSalary.text!) else{ return}
            guard let guardedPercentCommission = Double(salepersonUIView.intfCommission.text!) else {return}
            
            let saleperson:Saleperson = Saleperson(baseSalary: guardedBaseSalary, percentCommission: guardedPercentCommission)
            let salary = SalaryCalculateFunctions.setSalepersonSalary(companyRevenue: Company.revenue, baseSalary: saleperson.getBaseSalary(), percentCommission: saleperson.getPercentCommission())
            saleperson.setIncome(income: salary)
            
            salaryCalculatorView.tvSalaryDetail.text = "Salary of Saleperson \n \(saleperson.getIncome()) $"
            
        case "Worker":
            guard let guardedBaseSalary = Double(workerUIView.intfBaseSalary.text!) else{ return}
            guard let guardedMultiply = Double(workerUIView.intfMultiply.text!) else {return}
            
            let worker:Worker = Worker(baseSalary: guardedBaseSalary, multiply: guardedMultiply)
            let salary = SalaryCalculateFunctions.setWorkerSalary(companyProduct: Company.products, baseSalary: worker.getBaseSalary(), multiply: worker.getMultiply())
            worker.setIncome(income: salary)
            
            salaryCalculatorView.tvSalaryDetail.text = "Salary of Worker \n \(worker.getIncome()) $"
            
        default:
            salaryCalculatorView.tvSalaryDetail.text = "please choose kinds of employee"
        }
        
    }
   
    
    //===============================================================
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = Theme.backgroundColor
        layoutCompanyUIView()
        layoutDDBKindsEmployees()
        layoutEmployeesView()
        layoutSalaryCalculatorView()
        createObserver()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
